### Repository: grpc_calculator — Copilot instructions

This repository implements a small gRPC-based Calculator service in Python. The goal of these instructions is to help AI coding agents be immediately productive by highlighting the project's architecture, important files, patterns, and concrete examples to edit or extend.

- Big picture
  - service: A single gRPC service `Calculator` (defined in `calculator.proto`) exposing RPCs: `Add`, `Subtract`, `Multiply`, `Divide`, `Modulus`, `Power`, `SquareRoot`.
  - server: `server.py` implements `CalculatorServicer` and registers it on port 50051.
  - client: `client.py` contains an interactive CLI client showing usage of the RPCs. `__main__.py` starts the server in a background thread and runs a short client smoke test.

- Key files to reference when changing behavior
  - `calculator.proto` — canonical source for message and RPC shapes (regenerate stubs with `python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. calculator.proto`).
  - `server.py` — where business logic and logging live. Look here for validation, error handling, and response shaping.
  - `client.py` / `__main__.py` — examples for invoking the RPCs; use them for integration tests or examples.
  - `calculator_pb2.py`, `calculator_pb2_grpc.py` — generated code; edit only by changing the `.proto` and re-generating.

- Patterns and conventions in this repo (explicit, discoverable)
  - RPC signatures use `CalcRequest` (two doubles) for binary ops and `SingleRequest` for unary ops. Responses are `CalcResponse` with a `result` double.
  - Error signaling: `server.py` uses gRPC status codes via `context.set_details()` and `context.set_code()` (e.g., divide-by-zero or invalid sqrt input). Preserve this approach when adding validation.
  - Logging: server logs to `server.log` (via Python's `logging`). When adding features, add an informative `logging.info()` or `logging.error()` line similar to existing handlers.
  - Server lifecycle: `serve()` starts a threaded gRPC server listening on `0.0.0.0:50051`. Tests or tools should use `grpc.insecure_channel('localhost:50051')` to connect.

- Concrete examples (copy-paste friendly)
  - Call Add from Python client:
    - Create a stub: `stub = calculator_pb2_grpc.CalculatorStub(channel)`
    - Build request: `calculator_pb2.CalcRequest(number1=1.0, number2=2.0)`
    - Call: `stub.Add(request)` → returns `CalcResponse(result=...)`

  - Signal a validation error on server side:
    - `context.set_details("error message")`
    - `context.set_code(grpc.StatusCode.INVALID_ARGUMENT)`

- Developer workflows / commands (explicit)
  - Install dependencies: `pip install grpcio grpcio-tools`
  - Generate stubs when editing `calculator.proto`:
    - `python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. calculator.proto`
  - Run the server: `python server.py` (or `python __main__.py` to start server + short client test)
  - Run the interactive client: `python client.py` (choose operations as prompted)

- What to avoid / non-goals
  - Do not manually edit `calculator_pb2.py` or `calculator_pb2_grpc.py`—they are generated from the `.proto` file.
  - The project uses insecure, local channels for demo purposes. Don't add production TLS config unless the task explicitly requires it.

- Good first edits to demonstrate capability
  - Add a new RPC (e.g., `Average`) — edit `calculator.proto`, regenerate stubs, implement in `server.py`, and add a client call in `__main__.py`.
  - Improve logging format or rotate logs: update `logging.basicConfig(...)` in `server.py` and add more contextual logs.

If anything above is unclear or you want more examples (unit test template, CI step to generate stubs, or how to mock gRPC in tests), tell me which area to expand and I'll iterate.
